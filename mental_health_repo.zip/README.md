# Mental Health Agent System
Auto-generated GitHub-ready repository.

## Structure
- src/main.py (full notebook code)
- tests/
- docs/
- data/
- models/
- scripts/
- configs/
